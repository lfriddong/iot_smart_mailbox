package com.example.myapplication_box_1205;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONObject;
import android.os.AsyncTask;
import android.util.Log;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.util.Timer;
import java.util.TimerTask;
import java.io.IOException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.signature.ObjectKey;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;





/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {


    private ImageView imageView_home;
    private Handler mainHandler;
    private ScheduledExecutorService scheduledExecutorService;

    // Replace with your image URL
    private String imageUrl = "http://35.225.150.6/images/1.jpeg";

    private String[] imageList;
    private int index =0;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @NonNull ViewGroup container,
                             @NonNull Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        imageView_home = view.findViewById(R.id.image_view_home);

        mainHandler = new Handler(Looper.getMainLooper());
        startUpdatingImage();
        // Log.d("MyAppTag3", "打印的字符串: " + MainActivity.imageUrl);
        // loadImage(MainActivity.imageUrl);
       //  Log.d("MyAppTag", "打印的字符串: " + MainActivity.imageUrl);
        return view;

    }

    private void startUpdatingImage() {
        scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutorService.scheduleAtFixedRate(this::loadAndDisplayImage, 0, 5, TimeUnit.SECONDS);
    }

    private void loadAndDisplayImage() {
        // Perform the image loading in a background thread
        Executors.newSingleThreadExecutor().execute(() -> {
            // Load image using Glide or your preferred image loading library
            try {
                // Simulate loading the image from the URL
                // You should replace this with your actual image loading logic
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Update UI on the main thread
            mainHandler.post(() -> Glide.with(this).load("http://35.225.150.6/images/1.jpeg")
                    .apply(new RequestOptions().signature(new ObjectKey(String.valueOf(System.currentTimeMillis()))))
                    .into(imageView_home));
            Log.d("MyAppTag", "打印的字符串1: " + MainActivity.imageUrl);
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Stop the scheduled task when the fragment is destroyed
        if (scheduledExecutorService != null && !scheduledExecutorService.isShutdown()) {
            scheduledExecutorService.shutdown();
        }
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        Button btn_lock = view.findViewById(R.id.imageButton_lock);
        Button btn_unlock = view.findViewById(R.id.imageButton_unlock);

        btn_lock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AsyncTask<Void, Void, Void>() {
                    @Override
                    protected Void doInBackground(Void... voids) {
                        try {
                            URL url = new URL("http://35.225.150.6:5000/set_status");
                            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                            connection.setRequestMethod("POST");
                            connection.setRequestProperty("Content-Type", "application/json");
                            connection.setDoOutput(true);

                            String jsonInputString = "{\"door_open_permit\": false}";

                            try (OutputStream os = connection.getOutputStream()) {
                                byte[] input = jsonInputString.getBytes("utf-8");
                                os.write(input, 0, input.length);
                            }

                            int responseCode = connection.getResponseCode();
                            if (responseCode != HttpURLConnection.HTTP_OK) {
                                Log.e("PostRequest", "HTTP error code: " + responseCode);
                            }

                        } catch (Exception e) {
                            Log.e("PostRequest", "Error sending post request: " + e.getMessage());
                        }
                        return null;
                    }
                }.execute();

            }

        });

        btn_unlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AsyncTask<Void, Void, Void>() {
                    @Override
                    protected Void doInBackground(Void... voids) {
                        try {
                            URL url = new URL("http://35.225.150.6:5000/set_status");
                            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                            connection.setRequestMethod("POST");
                            connection.setRequestProperty("Content-Type", "application/json");
                            connection.setDoOutput(true);

                            String jsonInputString = "{\"door_open_permit\": true}";

                            try (OutputStream os = connection.getOutputStream()) {
                                byte[] input = jsonInputString.getBytes("utf-8");
                                os.write(input, 0, input.length);
                            }

                            int responseCode = connection.getResponseCode();
                            if (responseCode != HttpURLConnection.HTTP_OK) {
                                Log.e("PostRequest", "HTTP error code: " + responseCode);
                            }

                        } catch (Exception e) {
                            Log.e("PostRequest", "Error sending post request: " + e.getMessage());
                        }
                        return null;
                    }
                }.execute();

            }
        });






    }



    private void loadImage(String url) {
        Glide.with(this)
                .load(url)
                //.load(R.drawable.my_image)
                .centerCrop()
                .into(imageView_home);
    }




}