package com.example.myapplication_box_1205;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import android.widget.Button;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link DeliveryFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class DeliveryFragment extends Fragment {

    private ImageView imageView;

    private String[] imageList;
    private int index =0;

    String url = "https://wallpaperaccess.com/full/266770.jpg";

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public DeliveryFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment DeliveryFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static DeliveryFragment newInstance(String param1, String param2) {
        DeliveryFragment fragment = new DeliveryFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

   /* private void loadImage() {
        Glide.with(DeliveryFragment.this)
                .load(imageList[index])
                .centerCrop()
                .into(imageView);
    }


    public void nextImage(View view){
        index++;
        if(index >= imageList.length)
            index = 0;
        loadImage();

    }

    public void previousImage(View view){
        index--;
        if(index <= -1)
            index = 0;
        loadImage();

    }*/




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_delivery, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        imageView = view.findViewById(R.id.image_view);
        imageList = getResources().getStringArray(R.array.images);



        loadImage();
        Button nextButton = view.findViewById(R.id.btn_next);
        Button previousButton = view.findViewById(R.id.btn_previous);

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextImage();
            }
        });

        previousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previousImage();
            }
        });

    }

    private void loadImage() {
        Glide.with(this)
                .load(imageList[index])
                //.load(R.drawable.my_image)
                .centerCrop()
                .into(imageView);
        Log.d("MyAppTag4", "打印的字符串: " + imageList[index]);

    }

    public void nextImage(){
        index++;
        if(index >= imageList.length)
            index = 0;
        loadImage();

    }

    public void previousImage(){
        index--;
        if(index <= -1)
            index = 0;
        loadImage();
    }

}
