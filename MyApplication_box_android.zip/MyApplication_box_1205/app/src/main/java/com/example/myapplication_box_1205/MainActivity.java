package com.example.myapplication_box_1205;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import org.json.JSONObject;
import org.json.JSONObject;
import org.json.JSONException;
import android.os.Bundle;

import com.example.myapplication_box_1205.databinding.ActivityMainBinding;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;

import java.util.Timer;
import java.util.TimerTask;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.util.Timer;
import java.util.TimerTask;
import java.io.IOException;
import androidx.annotation.NonNull;






public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    private Timer timer;
    private Handler handler;

    public static String imageUrl;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        replaceFragment(new HomeFragment());
        binding.bottomNavigationView.setOnNavigationItemSelectedListener(item -> {

            if(item.getItemId()==R.id.home){
                replaceFragment(new HomeFragment());
            }else if(item.getItemId()==R.id.delivery){
                replaceFragment(new DeliveryFragment());
            }else{
                replaceFragment(new ProtectionFragment());
            }

            return true;
        });
        // 创建 Handler 用于处理获取图片 URL 的消息
         /*handler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                // 处理获取到的最新图片 URL，这里可以更新 UI 或执行其他操作
                try {//String imageUrl_i = (String) msg.obj;
                    String jsonString = (String) msg.obj;

                    // 创建 JSONObject 来解析这个字符串
                    JSONObject jsonObject = new JSONObject(jsonString);

                    // 从 JSON 对象中提取 "image_url" 键对应的值
                    String imageUrl = jsonObject.getString("image_url");

                    // 将提取的 URL 赋值给 MainActivity 的 imageUrl 变量
                    MainActivity.imageUrl = imageUrl;
                }catch (JSONException e) {
                    e.printStackTrace();
                    // 这里处理 JSON 解析异常
                    // 您可以记录日志或以其他方式处理异常
                }

                 //MainActivity.imageUrl = imageUrl;
                Log.d("MyAppTag", "打印的字符串1: " + MainActivity.imageUrl);
                if (imageUrl != null) {
                    // 在这里处理获取到的图片 URL，例如显示图片等
                    // 你可以根据你的需求在这里执行相关的操作
                    // 例如，你可以将图片 URL 设置给 ImageView 来显示图片
                    // imageView.setImageURI(Uri.parse(imageUrl));
                }
            }
        };*/
        // 启动轮询任务，每隔3秒请求一次最新图片 URL
        //startImageURLPolling();
    }


    /*private void startImageURLPolling() {
        final int pollingInterval = 3000; // 轮询间隔，单位为毫秒

        // 使用 Timer 定时执行轮询任务
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                // 创建并执行获取图片 URL 的任务
                new GetImageURLTask().execute();
            }
        }, 0, pollingInterval);
    }

    private class GetImageURLTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... params) {
            // 在后台发送请求获取最新的图片 URL
            try {
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url("http://35.225.150.6:5000/get_image_url")  // 替换成实际的服务器地址和路由
                        .build();

                Response response = client.newCall(request).execute();
                if (response.isSuccessful()) {
                    return response.body().string();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String imageUrl) {
            // 将获取到的最新图片 URL 发送到主线程处理
            if (imageUrl != null) {
                Message message = handler.obtainMessage();
                message.obj = imageUrl;
                handler.sendMessage(message);
            }
        }
    }*/










    private void replaceFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout,fragment);
        fragmentTransaction.commit();



    }
}









