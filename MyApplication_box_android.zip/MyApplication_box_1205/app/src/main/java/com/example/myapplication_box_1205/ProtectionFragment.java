package com.example.myapplication_box_1205;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.CompoundButton;
import android.util.Log;

import android.widget.Button;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONObject;
import android.os.AsyncTask;

import android.os.AsyncTask;
import android.util.Log;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;



import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.signature.ObjectKey;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;




/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProtectionFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProtectionFragment extends Fragment {

    private ImageView imageView_pro;
    private Handler mainHandler;

    private String imageUrl = "http://35.225.150.6/images/1.jpeg";
    private ScheduledExecutorService scheduledExecutorService;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ProtectionFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ProtectionFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ProtectionFragment newInstance(String param1, String param2) {
        ProtectionFragment fragment = new ProtectionFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    @Nullable
    @Override
    public View onCreateView(@Nullable LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_protection, container, false);
        imageView_pro = view.findViewById(R.id.image_view_pro);
        mainHandler = new Handler(Looper.getMainLooper());
        startUpdatingImage();
        return view;
    }

    private void startUpdatingImage() {
        scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutorService.scheduleAtFixedRate(this::loadAndDisplayImage, 0, 5, TimeUnit.SECONDS);
    }

    private void loadAndDisplayImage() {
        // Perform the image loading in a background thread
        Executors.newSingleThreadExecutor().execute(() -> {
            // Load image using Glide or your preferred image loading library
            try {
                // Simulate loading the image from the URL
                // You should replace this with your actual image loading logic
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Update UI on the main thread
            mainHandler.post(() -> Glide.with(this).load(imageUrl)
                    .apply(new RequestOptions().signature(new ObjectKey(String.valueOf(System.currentTimeMillis()))))
                    .into(imageView_pro));
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Stop the scheduled task when the fragment is destroyed
        if (scheduledExecutorService != null && !scheduledExecutorService.isShutdown()) {
            scheduledExecutorService.shutdown();
        }
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Button btn_pro_on = view.findViewById(R.id.protection_on);
        Button btn_pro_off = view.findViewById(R.id.protection_off);

        btn_pro_on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AsyncTask<Void, Void, Void>() {
                    @Override
                    protected Void doInBackground(Void... voids) {
                        try {
                            URL url = new URL("http://35.225.150.6:5000/set_status");
                            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                            connection.setRequestMethod("POST");
                            connection.setRequestProperty("Content-Type", "application/json");
                            connection.setDoOutput(true);

                            String jsonInputString = "{\"mannual_protect_on\": true}";

                            try (OutputStream os = connection.getOutputStream()) {
                                byte[] input = jsonInputString.getBytes("utf-8");
                                os.write(input, 0, input.length);
                            }

                            int responseCode = connection.getResponseCode();
                            if (responseCode != HttpURLConnection.HTTP_OK) {
                                Log.e("PostRequest", "HTTP error code: " + responseCode);
                            }

                        } catch (Exception e) {
                            Log.e("PostRequest", "Error sending post request: " + e.getMessage());
                        }
                        return null;
                    }
                }.execute();

            }

        });

        btn_pro_off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AsyncTask<Void, Void, Void>() {
                    @Override
                    protected Void doInBackground(Void... voids) {
                        try {
                            URL url = new URL("http://35.225.150.6:5000/set_status");
                            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                            connection.setRequestMethod("POST");
                            connection.setRequestProperty("Content-Type", "application/json");
                            connection.setDoOutput(true);

                            String jsonInputString = "{\"mannual_protect_off\": true}";

                            try (OutputStream os = connection.getOutputStream()) {
                                byte[] input = jsonInputString.getBytes("utf-8");
                                os.write(input, 0, input.length);
                            }

                            int responseCode = connection.getResponseCode();
                            if (responseCode != HttpURLConnection.HTTP_OK) {
                                Log.e("PostRequest", "HTTP error code: " + responseCode);
                            }

                        } catch (Exception e) {
                            Log.e("PostRequest", "Error sending post request: " + e.getMessage());
                        }
                        return null;
                    }
                }.execute();

            }

        });



    }




}